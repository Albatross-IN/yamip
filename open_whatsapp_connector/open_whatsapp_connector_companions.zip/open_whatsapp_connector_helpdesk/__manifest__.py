{
    'name': 'WhatsApp Helpdesk Tickets',
    'author': 'Roshan',
    'category': 'Productivity/WhatsApp',
    'summary': 'Two-way sync between WhatsApp conversations and Helpdesk Tickets.',
    'license': 'OPL-1',
    'version': '19.0.1.0.0',
    'images': ['static/description/banner.jpg'],
    'description': """
Glue addon that bridges Open WhatsApp Connector with Odoo Enterprise Helpdesk.

Installed automatically when both ``open_whatsapp_connector`` and ``helpdesk``
are present (auto_install=True).

Bi-directional bridge:
  - Inbound rule that creates a ``helpdesk.ticket`` from an inbound WhatsApp
    message stamps the link on BOTH sides (``discuss.channel
    .helpdesk_ticket_id_int`` AND ``helpdesk.ticket.wa_channel_id_int``).
  - Smart button on the WhatsApp channel form jumps to the linked ticket.
  - Smart button on the helpdesk ticket form jumps to the linked WhatsApp
    Discuss conversation.
  - Inbound WhatsApp messages are relayed to the linked ticket's chatter as
    internal notes so support agents see the conversation history without
    leaving the ticket.
  - Public agent comments on the ticket (subtype mt_comment) are relayed
    back to the customer as outbound WhatsApp messages, so support replies
    flow through the same WhatsApp thread the customer started.

Loop-safe via a ``skip_helpdesk_relay`` context flag set on each relayed
``message_post``.
    """,
    'depends': ['open_whatsapp_connector', 'helpdesk'],
    'data': [
        'views/helpdesk_ticket_views.xml',
    ],
    'auto_install': True,
    'installable': True,
    'application': False,
    'website': 'https://github.com/roshank8s/',
}
