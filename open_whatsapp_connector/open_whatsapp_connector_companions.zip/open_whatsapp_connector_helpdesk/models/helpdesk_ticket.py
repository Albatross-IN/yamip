"""Glue extension: bidirectional Helpdesk Ticket ↔ WhatsApp channel bridge.

Only loaded when both `open_whatsapp_connector` and `helpdesk` are installed
(see __manifest__.py — auto_install=True).
"""
import logging

from markupsafe import Markup

from odoo import _, api, fields, models
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class HelpdeskTicket(models.Model):
    _inherit = 'helpdesk.ticket'

    wa_channel_id_int = fields.Integer(
        string="WhatsApp Channel id",
        index=True,
        help="Numeric id of the discuss.channel (channel_type=whatsapp) that "
             "originated this ticket via an inbound rule. Stored as a plain "
             "integer because the helpdesk module loads before discuss.channel "
             "is augmented with WhatsApp fields.")

    def action_open_wa_channel(self):
        """Smart-button: open the linked WhatsApp Discuss conversation."""
        self.ensure_one()
        if not self.wa_channel_id_int:
            raise UserError(_("No WhatsApp conversation is linked to this ticket."))
        channel = self.env['discuss.channel'].browse(self.wa_channel_id_int)
        if not channel.exists():
            raise UserError(_(
                "The linked WhatsApp channel (id %s) no longer exists.",
                self.wa_channel_id_int))
        return {
            'type': 'ir.actions.act_window',
            'name': channel.display_name or _("WhatsApp Conversation"),
            'res_model': 'discuss.channel',
            'res_id': channel.id,
            'view_mode': 'form',
            'target': 'current',
        }

    def message_post(self, **kwargs):
        """Relay public agent comments to the linked WhatsApp channel.

        Triggered for:
          - subtype mail.mt_comment (public reply, not internal mt_note)
          - message_type 'comment' (not auto-generated tracking values)
          - wa_channel_id_int is set
          - context flag ``skip_helpdesk_relay`` NOT set (avoids loops with
            the inbound-side relay in discuss_channel.message_post)

        Fire-and-forget — relay failure never blocks the primary post.
        """
        message = super().message_post(**kwargs)
        if (self.wa_channel_id_int
                and not self.env.context.get('skip_helpdesk_relay')
                and kwargs.get('message_type') == 'comment'
                and kwargs.get('subtype_xmlid') == 'mail.mt_comment'):
            try:
                channel = self.env['discuss.channel'].sudo().browse(
                    self.wa_channel_id_int).exists()
                if channel and channel.channel_type == 'whatsapp':
                    channel.with_context(skip_helpdesk_relay=True).message_post(
                        body=message.body or Markup(''),
                        message_type='whatsapp_message',
                        subtype_xmlid='mail.mt_comment',
                        author_id=message.author_id.id if message.author_id else False,
                    )
            except Exception:
                _logger.exception(
                    "Helpdesk→WhatsApp relay failed for ticket %s channel %s",
                    self.id, self.wa_channel_id_int)
        return message
