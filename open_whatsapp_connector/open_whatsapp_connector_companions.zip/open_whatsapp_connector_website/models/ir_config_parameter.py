from urllib.parse import quote

from odoo import models


class IrConfigParameter(models.Model):
    _inherit = 'ir.config_parameter'

    def owa_website_widget(self):
        """Return the floating-button config for the website QWeb template.

        Reads the three config params written by the base module's Settings
        panel and returns a dict:
            {'enabled': True, 'href': 'https://wa.me/<digits>?text=<encoded>'}
        or {'enabled': False} when the widget is off / no number configured.
        The message is URL-encoded so spaces / & / ? don't break the link.
        """
        get = self.sudo().get_param
        enabled = get('open_whatsapp_connector.website_widget_enabled')
        if not enabled or str(enabled).lower() in ('false', '0', ''):
            return {'enabled': False}
        phone = (get('open_whatsapp_connector.website_widget_phone') or '')
        phone = phone.replace('+', '').replace(' ', '').replace('-', '')
        if not phone:
            return {'enabled': False}
        href = 'https://wa.me/%s' % phone
        message = get('open_whatsapp_connector.website_widget_message') or ''
        if message:
            href += '?text=%s' % quote(message, safe='')
        return {'enabled': True, 'href': href}
