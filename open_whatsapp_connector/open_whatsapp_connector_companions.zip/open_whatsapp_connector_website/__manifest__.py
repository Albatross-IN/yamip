{
    'name': 'WhatsApp Website Button',
    'author': 'Roshan',
    'category': 'Productivity/WhatsApp',
    'summary': 'Floating WhatsApp click-to-chat button on the Odoo website.',
    'license': 'OPL-1',
    'version': '19.0.1.0.0',
    'images': ['static/description/banner.jpg'],
    'description': """
Auto-installed when both Open WhatsApp Connector and the Website module are
present. Renders a fixed-position WhatsApp chat bubble on every public website
page (wa.me deep link to your configured number, with an optional prefilled
message). Configure it under Settings -> Open WhatsApp Connector -> "Website
WhatsApp Widget" (Enable + Phone + Message). No Meta API required - it's a
plain wa.me click-to-chat link.
    """,
    'depends': ['open_whatsapp_connector', 'website'],
    'data': [
        'views/website_layout_widget.xml',
    ],
    'assets': {
        'web.assets_frontend': [
            'open_whatsapp_connector_website/static/src/scss/owa_website_widget.scss',
        ],
    },
    'auto_install': True,
    'installable': True,
    'application': False,
    'website': 'https://github.com/roshank8s/',
}
