import base64
import logging
from datetime import timedelta

from odoo import api, fields, models, _

_logger = logging.getLogger(__name__)


def queue_wa_message(env, account, phone, body, record=None, attachment_ids=None):
    """Shared helper: build the mail.message (so owa.message.body — a related
    field — isn't dropped) + the outbound owa.message, then trigger the send
    cron. Returns the owa.message (or None on no phone/account)."""
    if not account or not phone:
        return None
    mail_message = env['mail.message'].sudo().create({
        'model': record._name if record else False,
        'res_id': record.id if record else False,
        'body': body or '',
        'message_type': 'whatsapp_message',
        'attachment_ids': [(6, 0, attachment_ids or [])],
    })
    msg = env['owa.message'].sudo().create({
        'mobile_number': phone,
        'message_type': 'outbound',
        'state': 'outgoing',
        'wa_account_id': account.id,
        'mail_message_id': mail_message.id,
    })
    cron = env.ref('open_whatsapp_connector.ir_cron_send_owa_queue',
                   raise_if_not_found=False)
    if cron:
        cron.sudo()._trigger()
    return msg


def render_invoice_pdf(env, invoice):
    """Render the customer-invoice PDF for ``invoice`` → ir.attachment, or None."""
    report = env.ref('account.account_invoices', raise_if_not_found=False)
    if not report:
        return None
    try:
        pdf_bytes, _dummy = report.sudo()._render_qweb_pdf(report.report_name, invoice.ids)
        return env['ir.attachment'].sudo().create({
            'name': '%s.pdf' % (invoice.name or 'Invoice'),
            'res_model': 'account.move',
            'res_id': invoice.id,
            'mimetype': 'application/pdf',
            'datas': base64.b64encode(pdf_bytes),
        })
    except Exception:
        _logger.exception("owa dunning: invoice PDF render failed for %s", invoice.id)
        return None


class OwaDunningConfig(models.Model):
    _name = 'owa.account.dunning.config'
    _description = 'WhatsApp Dunning Configuration'

    name = fields.Char(default='WhatsApp Dunning', required=True)
    active = fields.Boolean(default=True)
    wa_account_id = fields.Many2one(
        'owa.account', string="WhatsApp Account", required=True,
        domain=[('session_state', '=', 'connected')])
    bucket_7_enabled = fields.Boolean(string="7-day reminder", default=True)
    bucket_30_enabled = fields.Boolean(string="30-day reminder", default=True)
    bucket_60_enabled = fields.Boolean(string="60-day reminder", default=True)
    template_id = fields.Many2one(
        'owa.quick.reply', string="Reminder Template",
        default=lambda self: self.env.ref(
            'open_whatsapp_connector.quick_reply_dun_invoice_overdue',
            raise_if_not_found=False))
    attach_invoice_pdf = fields.Boolean(string="Attach Invoice PDF", default=True)
    send_log_ids = fields.One2many(
        'owa.dunning.send.log', 'config_id', string="Send Log")

    _sql_constraints = [
        ('one_per_account', 'unique(wa_account_id)',
         'There is already a dunning configuration for this WhatsApp account.'),
    ]

    @api.model
    def _cron_send_dunning(self):
        today = fields.Date.today()
        SendLog = self.env['owa.dunning.send.log'].sudo()
        for config in self.search([('active', '=', True)]):
            if not config.template_id or config.wa_account_id.session_state != 'connected':
                continue
            buckets = [
                (7, config.bucket_7_enabled),
                (30, config.bucket_30_enabled),
                (60, config.bucket_60_enabled),
            ]
            for days, enabled in buckets:
                if not enabled:
                    continue
                cutoff = today - timedelta(days=days)
                inv_domain = [
                    ('move_type', '=', 'out_invoice'),
                    ('state', '=', 'posted'),
                    ('payment_state', 'in', ('not_paid', 'partial')),
                    ('invoice_date_due', '=', cutoff),
                ]
                # Scope to the account's own companies — otherwise a config for
                # company A dunned company B's overdue invoices too. (#F091)
                company_ids = config.wa_account_id.allowed_company_ids.ids
                if company_ids:
                    inv_domain.append(('company_id', 'in', company_ids))
                invoices = self.env['account.move'].sudo().search(inv_domain)
                for invoice in invoices:
                    if not invoice.partner_id.phone:
                        continue
                    # dedup: one send per (invoice, bucket) GLOBALLY — not per
                    # config. With multiple active configs (one per account)
                    # serving the same company, a config_id-scoped dedupe sent
                    # the same reminder once per config. (#F091)
                    if SendLog.search_count([
                            ('invoice_id', '=', invoice.id),
                            ('days_bucket', '=', days)]):
                        continue
                    try:
                        config._send_dunning_for_invoice(invoice, days)
                        SendLog.create({
                            'config_id': config.id,
                            'invoice_id': invoice.id,
                            'days_bucket': days,
                        })
                    except Exception:
                        _logger.exception(
                            "owa dunning: send failed for invoice %s bucket %s",
                            invoice.id, days)

    def _send_dunning_for_invoice(self, invoice, days):
        self.ensure_one()
        from odoo.addons.open_whatsapp_connector.tools.phone_validation import wa_phone_format
        partner = invoice.partner_id
        phone = wa_phone_format(self.env, partner.phone or '') or partner.phone
        if not phone:
            return
        free_text = {
            'partner_name': partner.name or '',
            'currency': invoice.currency_id.symbol or invoice.currency_id.name or '',
            'amount': '%.2f' % (invoice.amount_residual or 0.0),
            'days_overdue': str(days),
            'record_name': invoice.name or '',
            'record_url': invoice.get_base_url(),
        }
        body = self.template_id.render_body(record=invoice, free_text_values=free_text)
        att_ids = []
        if self.attach_invoice_pdf:
            att = render_invoice_pdf(self.env, invoice)
            if att:
                att_ids = [att.id]
        queue_wa_message(self.env, self.wa_account_id, phone, body,
                         record=invoice, attachment_ids=att_ids)


class OwaDunningSendLog(models.Model):
    _name = 'owa.dunning.send.log'
    _description = 'WhatsApp Dunning Send Log'
    _order = 'id desc'

    config_id = fields.Many2one(
        'owa.account.dunning.config', ondelete='cascade', required=True)
    invoice_id = fields.Many2one('account.move', ondelete='cascade', required=True)
    days_bucket = fields.Integer(required=True)
