import base64
import logging

from odoo import models, _
from odoo.exceptions import UserError

from .owa_dunning import queue_wa_message

_logger = logging.getLogger(__name__)


class ResPartner(models.Model):
    _inherit = 'res.partner'

    def action_send_wa_statement(self):
        """Send the customer's open-invoice statement over WhatsApp.
        Uses the account_followup statement PDF when that module is installed,
        otherwise sends a plain-text summary of outstanding invoices."""
        self.ensure_one()
        from odoo.addons.open_whatsapp_connector.tools.phone_validation import wa_phone_format
        phone = wa_phone_format(self.env, self.phone or '') or self.phone
        if not phone:
            raise UserError(_("This contact has no phone number."))
        account = self.env['owa.account'].search(
            [('session_state', '=', 'connected')], limit=1)
        if not account:
            raise UserError(_(
                "No connected WhatsApp account. Connect one under WhatsApp → "
                "Configuration → Accounts."))

        invoices = self.env['account.move'].sudo().search([
            ('partner_id', '=', self.id),
            ('move_type', '=', 'out_invoice'),
            ('state', '=', 'posted'),
            ('payment_state', 'in', ('not_paid', 'partial')),
        ])
        if not invoices:
            return {
                'type': 'ir.actions.client', 'tag': 'display_notification',
                'params': {
                    'title': _("Nothing to send"),
                    'message': _("%s has no open customer invoices.") % self.name,
                    'type': 'warning', 'sticky': False,
                },
            }

        att_ids = []
        body = _("Hi %s, here is your account statement.") % (self.name or '')
        # Branch A: account_followup statement PDF (when the module is present).
        followup_report = self.env.ref(
            'account_followup.action_report_followup', raise_if_not_found=False)
        pdf_bytes = None
        if followup_report:
            try:
                pdf_bytes, _dummy = followup_report.sudo()._render_qweb_pdf(
                    'account_followup.report_followup_print_all', self.id,
                    data={'options': {}})
            except Exception:
                _logger.exception(
                    "owa statement: followup PDF render failed for partner %s", self.id)
                pdf_bytes = None
        if pdf_bytes:
            att = self.env['ir.attachment'].sudo().create({
                'name': _("Statement - %s.pdf") % (self.name or 'Customer'),
                'res_model': 'res.partner', 'res_id': self.id,
                'mimetype': 'application/pdf',
                'datas': base64.b64encode(pdf_bytes),
            })
            att_ids = [att.id]
        else:
            # Branch B: plain-text summary fallback.
            lines = [_("Hi %s, your open invoices:") % (self.name or '')]
            total = 0.0
            for inv in invoices:
                total += inv.amount_residual or 0.0
                lines.append("• %s — due %s — %s%.2f" % (
                    inv.name or '?', inv.invoice_date_due or '-',
                    inv.currency_id.symbol or '', inv.amount_residual or 0.0))
            cur = invoices[:1].currency_id.symbol or ''
            lines.append(_("Total outstanding: %s%.2f") % (cur, total))
            body = "\n".join(lines)

        queue_wa_message(self.env, account, phone, body, record=self, attachment_ids=att_ids)
        return {
            'type': 'ir.actions.client', 'tag': 'display_notification',
            'params': {
                'title': _("Statement queued"),
                'message': _("Sending statement to %s on WhatsApp.") % self.name,
                'type': 'success', 'sticky': False,
            },
        }
