{
    'name': 'WhatsApp Statements & Reminders',
    'author': 'Roshan',
    'category': 'Productivity/WhatsApp',
    'summary': 'Send customer statements and overdue-invoice dunning reminders over WhatsApp.',
    'license': 'OPL-1',
    'version': '19.0.1.0.0',
    'images': ['static/description/banner.jpg'],
    'description': """
Auto-installed when both Open WhatsApp Connector and Accounting are present.

- "Send Statement on WhatsApp" button on a contact: sends the customer their
  open-invoice statement (followup PDF when account_followup is installed,
  else a plain-text summary).
- WhatsApp dunning cadence: a daily cron finds overdue customer invoices at
  configurable day-buckets (7 / 30 / 60) and sends the matching reminder
  template (optionally with the invoice PDF). Deduplicated per invoice+bucket.

No Meta API required - sends through the Open WhatsApp Connector.
    """,
    'depends': ['open_whatsapp_connector', 'account'],
    'data': [
        'security/ir.model.access.csv',
        'data/owa_account_cron_data.xml',
        'views/owa_dunning_views.xml',
    ],
    'auto_install': True,
    'installable': True,
    'application': False,
    'website': 'https://github.com/roshank8s/',
}
