# The catalog-session inbound dispatch used to override OwaWebhook._check_chatbot
# here, but the base module moved that hook from controllers/main.py onto the
# owa.account MODEL (shared by the QR and Cloud transports). The override now
# lives in models/owa_account.py; this controller override was dead. (#F090)
