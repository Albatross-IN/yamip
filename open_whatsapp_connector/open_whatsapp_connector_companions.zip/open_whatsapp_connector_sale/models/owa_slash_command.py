from odoo import fields, models, _


class OwaSlashCommand(models.Model):
    _inherit = 'owa.slash.command'

    handler = fields.Selection(
        selection_add=[('catalog', '/catalog — browse products')],
        ondelete={'catalog': 'set default'})

    def _handle_catalog(self, account, from_number, body, channel):
        """Slash-command handler: open a fresh catalog session and send the
        interactive product list."""
        from odoo.addons.open_whatsapp_connector.tools.phone_validation import (
            wa_phone_format)
        Session = self.env['owa.catalog.session'].sudo()
        Menu = self.env['owa.catalog.menu'].sudo()
        formatted = wa_phone_format(self.env, from_number) or from_number
        menu = Menu.search([
            '|', ('wa_account_id', '=', account.id), ('wa_account_id', '=', False),
            ('active', '=', True),
        ], limit=1)
        if not menu:
            self._send_reply(
                account, from_number, _("No product catalog is configured yet."))
            return
        # Reset any prior active session for this number + account.
        Session.search([
            ('phone_number', '=', formatted),
            ('wa_account_id', '=', account.id),
            ('state', 'in', ['browsing', 'confirming']),
        ]).write({'state': 'cancelled'})
        session = Session.create({
            'phone_number': formatted,
            'wa_account_id': account.id,
            'catalog_menu_id': menu.id,
            'state': 'browsing',
        })
        session._send_catalog()
