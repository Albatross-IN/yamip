import logging
import re
from datetime import timedelta

from odoo import api, fields, models, _

_logger = logging.getLogger(__name__)


class OwaCatalogSession(models.Model):
    _name = 'owa.catalog.session'
    _description = 'WhatsApp Catalog Order Session'
    _order = 'last_activity desc'

    phone_number = fields.Char(required=True, index=True)
    wa_account_id = fields.Many2one(
        'owa.account', required=True, ondelete='cascade')
    catalog_menu_id = fields.Many2one(
        'owa.catalog.menu', required=True, ondelete='cascade')
    state = fields.Selection([
        ('browsing', 'Browsing'),
        ('confirming', 'Awaiting Confirmation'),
        ('done', 'Done'),
        ('cancelled', 'Cancelled'),
    ], default='browsing', index=True)
    sale_order_id = fields.Many2one(
        'sale.order', string="Draft Order", ondelete='set null')
    line_ids = fields.One2many(
        'owa.catalog.session.line', 'session_id', string="Cart")
    last_activity = fields.Datetime(default=lambda self: fields.Datetime.now())
    cart_summary = fields.Text(compute='_compute_cart_summary')

    @api.depends('line_ids.qty', 'line_ids.product_id')
    def _compute_cart_summary(self):
        for session in self:
            session.cart_summary = session._cart_summary_text()

    # ------------------------------------------------------------------
    # Partner / Sale Order
    # ------------------------------------------------------------------
    def _resolve_partner(self):
        self.ensure_one()
        return self.env['res.partner'].sudo()._find_or_create_from_wa_number(
            self.phone_number)

    def _get_or_create_so(self):
        self.ensure_one()
        if self.sale_order_id and self.sale_order_id.state in ('draft', 'sent'):
            return self.sale_order_id
        partner = self._resolve_partner()
        so = self.env['sale.order'].sudo().create({
            'partner_id': partner.id,
            'origin': _("WhatsApp Catalog — %s") % (self.phone_number or ''),
        })
        self.sale_order_id = so.id
        return so

    def _add_item(self, item, qty=1):
        self.ensure_one()
        so = self._get_or_create_so()
        SOL = self.env['sale.order.line'].sudo()
        line = SOL.search([
            ('order_id', '=', so.id),
            ('product_id', '=', item.product_id.id),
        ], limit=1)
        if line:
            line.write({'product_uom_qty': line.product_uom_qty + qty})
        else:
            SOL.create({
                'order_id': so.id,
                'product_id': item.product_id.id,
                'product_uom_qty': qty,
            })
        sl = self.line_ids.filtered(lambda l: l.product_id == item.product_id)
        if sl:
            sl.qty += qty
        else:
            self.env['owa.catalog.session.line'].create({
                'session_id': self.id,
                'product_id': item.product_id.id,
                'qty': qty,
            })

    def _cart_summary_text(self):
        self.ensure_one()
        if not self.line_ids:
            return _("(empty)")
        # Prefix each line with its catalog number so "remove 2" is intuitive.
        items = self.catalog_menu_id._all_items()
        pos = {it.product_id.id: i for i, it in enumerate(items, 1)}
        lines = []
        total = 0.0
        cur = ''
        for sl in self.line_ids:
            amount = sl.product_id.lst_price * sl.qty
            total += amount
            cur = sl.product_id.currency_id.name or cur
            n = pos.get(sl.product_id.id)
            prefix = ("%d. " % n) if n else "• "
            lines.append("%s%s x%g — %.2f" % (
                prefix, sl.product_id.name, sl.qty, amount))
        lines.append(_("Total: %(total).2f %(cur)s", total=total, cur=cur))
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Messaging
    # ------------------------------------------------------------------
    def _send_reply(self, text):
        self.ensure_one()
        from odoo.addons.open_whatsapp_connector.tools.phone_validation import (
            wa_phone_format)
        formatted = wa_phone_format(self.env, self.phone_number) or self.phone_number
        mail_msg = self.env['mail.message'].sudo().create({
            'body': text or '',
            'message_type': 'whatsapp_message',
        })
        self.env['owa.message'].sudo().create({
            'mobile_number': formatted,
            'message_type': 'outbound',
            'state': 'outgoing',
            'wa_account_id': self.wa_account_id.id,
            'mail_message_id': mail_msg.id,
        })
        cron = self.env.ref('open_whatsapp_connector.ir_cron_send_owa_queue',
                            raise_if_not_found=False)
        if cron:
            cron.sudo()._trigger()

    def _send_catalog(self):
        """Send the catalog menu: a numbered text body (always readable on any
        phone) with the interactive WhatsApp list layered on top (for clients
        that render it). The customer can tap a row OR reply with the number /
        product name."""
        self.ensure_one()
        menu = self.catalog_menu_id
        items = menu._all_items()
        sections = menu._build_list_sections()
        if not items:
            self._send_reply(_("Sorry, the catalog is empty right now."))
            return
        lines = [menu.body_text or _("Browse our products:"), ""]
        for i, it in enumerate(items, 1):
            cur = (it.product_id.currency_id.symbol
                   or it.product_id.currency_id.name or '')
            lines.append("%d. %s — %s%.2f" % (
                i, it.product_id.name, cur, it.product_id.lst_price))
        lines.append("")
        lines.append(_("Reply with the number to add a product (e.g. *2*), or "
                       "*2 x3* to add three. Then *CART* to review or *DONE* to "
                       "order. Reply *HELP* for all commands."))
        body = "\n".join(lines)
        # Best-effort interactive list (renders only where the WhatsApp client
        # supports it; on unofficial connections it is relayed but usually not
        # rendered, so it is NOT relied upon).
        try:
            number = (self.phone_number or '').lstrip('+')
            self.wa_account_id._get_baileys_api().send_list(
                number, body, menu.button_text or "View Products", sections,
                footer=menu.footer_text or None)
        except Exception:
            _logger.exception("catalog: interactive list send failed")
        # Always send the numbered text menu too — this is the reliable path,
        # so the customer can order (reply with number / name) even when the
        # interactive list does not render.
        self._send_reply(body)

    # ------------------------------------------------------------------
    # Inbound dispatch
    # ------------------------------------------------------------------
    @api.model
    def _dispatch_inbound(self, account, from_number, body):
        """Route an inbound message to an active session. Returns True if a
        session handled it (so the caller short-circuits the chatbot)."""
        from odoo.addons.open_whatsapp_connector.tools.phone_validation import (
            wa_phone_format)
        formatted = wa_phone_format(self.env, from_number) or from_number
        session = self.search([
            ('wa_account_id', '=', account.id),
            '|', ('phone_number', '=', formatted), ('phone_number', '=', from_number),
            ('state', 'in', ['browsing', 'confirming']),
        ], limit=1)
        if not session:
            return False
        return session._process_inbound(body or '')

    def _match_pick(self, pick_text):
        """Return the 0-based catalog index for a number/name pick, else None."""
        from odoo.addons.open_whatsapp_connector.tools.menu_match import (
            match_menu_choice)
        items = self.catalog_menu_id._all_items()
        labels = [(it.custom_title or it.product_id.name or '') for it in items]
        idx = match_menu_choice(labels, pick_text)
        if idx is not None and 0 <= idx < len(items):
            return idx
        return None

    def _process_inbound(self, body):
        self.ensure_one()
        self.last_activity = fields.Datetime.now()
        text = (body or '').strip()
        low = text.lower()
        # --- exact-word commands (checked before product match so a number or
        #     name can never hijack them) ---
        if low in ('cancel', 'no', 'n', 'stop'):
            return self._cancel()
        if low in ('done', 'yes', 'y', 'confirm', 'ok', 'order', 'checkout', 'pay'):
            return self._confirm()
        if low in ('cart', 'basket', 'items', 'view'):
            return self._show_cart()
        if low in ('help', '?', 'commands', 'h'):
            return self._show_help()
        if low in ('menu', 'list', 'products', 'catalog', 'back'):
            self._send_catalog()
            return True
        if low in ('clear', 'empty', 'reset'):
            return self._clear_cart()
        # --- prefixed commands: "<cmd> <arg>". A required separator (space, or
        #     ':'/'-') after the keyword avoids swallowing product names like
        #     "Notebook" / "Address Label". start(1) maps the lowercase match
        #     back onto the original-case text. ---
        mrem = re.match(r'^(?:remove|delete|del|rm|drop)\s+(.+)$', low)
        if mrem:
            return self._remove_pick(text[mrem.start(1):].strip())
        minfo = re.match(r'^(?:info|details|detail|describe|about)\s+(.+)$', low)
        if minfo:
            return self._product_info(text[minfo.start(1):].strip())
        msearch = re.match(r'^(?:search|find)\s+(.+)$', low)
        if msearch:
            return self._search_products(text[msearch.start(1):].strip())
        mnote = re.match(
            r'^(?:note|address|delivery|comment)(?:\s*[:\-]\s*|\s+)(.+)$', low)
        if mnote:
            return self._set_note(text[mnote.start(1):].strip())
        # --- inline quantity: "<pick> x<n>" adds several at once; qty 0 removes
        #     the product. (group 1 = product number/name, group 2 = quantity.) ---
        qty = 1
        pick_text = text
        m = re.match(r'^(.*?)\s*[x*×X]\s*(\d+)\s*$', text)
        if m and m.group(1).strip():
            pick_text = m.group(1).strip()
            try:
                qty = max(0, min(int(m.group(2)), 999))
            except ValueError:
                qty = 1
        # Menu pick — accept a tap echo, a number, or the product name.
        idx = self._match_pick(pick_text)
        if idx is not None:
            items = self.catalog_menu_id._all_items()
            if qty == 0:
                return self._remove_item_obj(items[idx].product_id)
            return self._add_item_and_reply(items[idx], qty=qty)
        if text.startswith('[List]'):
            # An interactive echo we couldn't map — let the normal pipeline run.
            return False
        self._send_reply(_(
            "Sorry, I didn't get that. Reply a *number* or *name* to add a "
            "product, *2 x3* for several, *CART* to review, *HELP* for all "
            "commands, or *CANCEL* to stop."))
        return True

    def _add_item_and_reply(self, item, qty=1):
        self.ensure_one()
        self._add_item(item, qty=qty)
        self.state = 'confirming'
        self._send_reply(_(
            "Added *%(qty)s × %(product)s*.\n\nYour cart:\n%(cart)s\n\nReply a "
            "number to add one more (or *N xQTY* for several), *CART* to review, "
            "*DONE* to place the order, or *CANCEL* to abandon.",
            qty=qty, product=item.product_id.name,
            cart=self._cart_summary_text()))
        return True

    def _show_cart(self):
        self.ensure_one()
        if not self.line_ids:
            self._send_reply(_(
                "Your cart is empty. Choose a product by number or name from "
                "the list above."))
            return True
        self._send_reply(_(
            "Your cart:\n%(cart)s\n\nReply a number to add more (or *N xQTY*), "
            "*DONE* to place the order, or *CANCEL* to abandon.",
            cart=self._cart_summary_text()))
        return True

    def _show_help(self):
        self.ensure_one()
        self._send_reply(_(
            "*How to order:*\n"
            "• A *number* adds that product (e.g. *2*)\n"
            "• *2 x3* — add 3 at once   •   *2 x0* — remove it\n"
            "• *info 2* — product details\n"
            "• *search desk* — find a product\n"
            "• *remove 2* — remove from cart   •   *clear* — empty cart\n"
            "• *note <text>* — add a delivery note\n"
            "• *cart* — review   •   *menu* — show products again\n"
            "• *done* — place the order   •   *cancel* — abandon"))
        return True

    def _clear_cart(self):
        self.ensure_one()
        self.line_ids.unlink()
        if self.sale_order_id and self.sale_order_id.state in ('draft', 'sent'):
            self.sale_order_id.sudo().order_line.unlink()
        self.state = 'browsing'
        self._send_reply(_(
            "🗑️ Cart cleared. Reply a number or name to start again, *MENU* to "
            "see the products, or *CANCEL* to exit."))
        return True

    def _remove_pick(self, arg):
        self.ensure_one()
        idx = self._match_pick(arg)
        if idx is None:
            self._send_reply(_(
                "I couldn't find \"%(arg)s\" to remove. Reply *CART* to see "
                "your items.", arg=arg))
            return True
        items = self.catalog_menu_id._all_items()
        return self._remove_item_obj(items[idx].product_id)

    def _remove_item_obj(self, product):
        self.ensure_one()
        sl = self.line_ids.filtered(lambda l: l.product_id == product)
        if not sl:
            self._send_reply(_(
                "*%(product)s* isn't in your cart. Reply *CART* to review.",
                product=product.name))
            return True
        sl.unlink()
        if self.sale_order_id and self.sale_order_id.state in ('draft', 'sent'):
            sol = self.sale_order_id.sudo().order_line.filtered(
                lambda l: l.product_id == product)
            if sol:
                sol.unlink()
        if not self.line_ids:
            self.state = 'browsing'
            self._send_reply(_(
                "Removed *%(product)s*. Your cart is now empty — reply a number "
                "to add a product or *CANCEL* to exit.", product=product.name))
            return True
        self._send_reply(_(
            "Removed *%(product)s*.\n\nYour cart:\n%(cart)s\n\nReply *DONE* to "
            "order or *CANCEL* to abandon.",
            product=product.name, cart=self._cart_summary_text()))
        return True

    def _product_info(self, arg):
        self.ensure_one()
        idx = self._match_pick(arg)
        if idx is None:
            self._send_reply(_(
                "I couldn't find \"%(arg)s\". Reply *MENU* to see the list or a "
                "number from it.", arg=arg))
            return True
        from odoo.tools import html2plaintext
        p = self.catalog_menu_id._all_items()[idx].product_id
        cur = p.currency_id.symbol or p.currency_id.name or ''
        desc = html2plaintext(p.description_sale or '').strip()
        body = _("*%(name)s*\n%(cur)s%(price).2f",
                 name=p.name, cur=cur, price=p.lst_price)
        if desc:
            body += "\n\n" + desc
        body += "\n\n" + _("Reply *%(n)s* to add it to your cart.", n=idx + 1)
        self._send_reply(body)
        return True

    def _search_products(self, kw):
        self.ensure_one()
        kw_low = (kw or '').lower().strip()
        items = self.catalog_menu_id._all_items()
        hits = [(i, it) for i, it in enumerate(items, 1)
                if kw_low and kw_low in (
                    (it.custom_title or it.product_id.name or '').lower())]
        if not hits:
            self._send_reply(_(
                "No products match \"%(kw)s\". Reply *MENU* to see the full "
                "list.", kw=kw))
            return True
        lines = [_("Matches for \"%(kw)s\":", kw=kw)]
        for i, it in hits:
            cur = (it.product_id.currency_id.symbol
                   or it.product_id.currency_id.name or '')
            lines.append("%d. %s — %s%.2f" % (
                i, it.product_id.name, cur, it.product_id.lst_price))
        lines.append("")
        lines.append(_("Reply with a number to add it (or *N xQTY*)."))
        self._send_reply("\n".join(lines))
        return True

    def _set_note(self, note):
        self.ensure_one()
        note = (note or '').strip()
        if not note:
            return True
        from odoo.tools import html2plaintext, plaintext2html
        so = self._get_or_create_so()
        existing = html2plaintext(so.note or '').strip()
        merged = (existing + "\n" if existing else "") + note
        so.sudo().note = plaintext2html(merged)
        self._send_reply(_(
            "📝 Noted: %(note)s\n\nReply *DONE* to place the order or keep "
            "adding products.", note=note))
        return True

    def _confirm(self):
        self.ensure_one()
        if not self.line_ids:
            self._send_reply(_(
                "Your cart is empty. Please choose a product from the list first."))
            return True
        so = self._get_or_create_so()
        if self.catalog_menu_id.auto_confirm and so.state in ('draft', 'sent'):
            try:
                so.sudo().action_confirm()
            except Exception:
                _logger.exception("Catalog: action_confirm failed for SO %s", so.id)
        self.state = 'done'
        msg = (self.catalog_menu_id.confirm_message
               or _("Order recorded. Thank you!"))
        self._send_reply(_(
            "%(msg)s\n\n*Order %(ref)s*\n%(summary)s",
            msg=msg, ref=so.name or '', summary=self._cart_summary_text()))
        return True

    def _cancel(self):
        self.ensure_one()
        if self.sale_order_id and self.sale_order_id.state in ('draft', 'sent'):
            try:
                self.sale_order_id.sudo().action_cancel()
            except Exception:
                _logger.exception(
                    "Catalog: cancel failed for SO %s", self.sale_order_id.id)
        self.state = 'cancelled'
        self._send_reply(
            self.catalog_menu_id.cancel_message or _("Order cancelled."))
        return True

    @api.model
    def _cron_expire_sessions(self):
        now = fields.Datetime.now()
        for session in self.search([('state', 'in', ['browsing', 'confirming'])]):
            timeout = session.catalog_menu_id.session_timeout_minutes or 30
            if (session.last_activity
                    and session.last_activity + timedelta(minutes=timeout) < now):
                session.state = 'cancelled'


class OwaCatalogSessionLine(models.Model):
    _name = 'owa.catalog.session.line'
    _description = 'WhatsApp Catalog Session Line'

    session_id = fields.Many2one(
        'owa.catalog.session', required=True, ondelete='cascade')
    product_id = fields.Many2one('product.product', required=True)
    qty = fields.Float(default=1.0)
