import logging

from odoo import models

_logger = logging.getLogger(__name__)


class OwaAccount(models.Model):
    _inherit = 'owa.account'

    def _check_chatbot(self, from_number, message_text, is_new_channel=False):
        """An active catalog session captures the conversation (list picks +
        DONE/CANCEL) before the generic chatbot gets a turn.

        The base ``_check_chatbot`` hook moved from controllers/main.py onto the
        owa.account MODEL (so both the QR and Cloud transports share it), so the
        catalog dispatch must override it HERE — the old controller-level
        override was dead and catalog ordering never resumed mid-chat. (#F090)
        """
        self.ensure_one()
        try:
            if self.env['owa.catalog.session'].sudo()._dispatch_inbound(
                    self, from_number, message_text):
                return True
        except Exception:
            _logger.exception("Error in catalog-session dispatch")
        return super()._check_chatbot(
            from_number, message_text, is_new_channel=is_new_channel)
