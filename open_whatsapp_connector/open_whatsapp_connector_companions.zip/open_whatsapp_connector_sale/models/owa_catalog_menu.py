import uuid

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class OwaCatalogMenu(models.Model):
    _name = 'owa.catalog.menu'
    _description = 'WhatsApp Product Catalog'
    _order = 'name'

    name = fields.Char(required=True)
    active = fields.Boolean(default=True)
    wa_account_id = fields.Many2one(
        'owa.account', string="WhatsApp Account",
        help="Leave empty to make this catalog available on all accounts.")
    body_text = fields.Text(string="Intro Message", default="Browse our products:")
    button_text = fields.Char(string="List Button Text", default="View Products")
    footer_text = fields.Char(string="Footer")
    section_ids = fields.One2many(
        'owa.catalog.menu.section', 'menu_id', string="Sections")
    confirm_message = fields.Text(
        string="Confirmation Message",
        default="Your order has been recorded. Our team will be in touch "
                "shortly. Thank you!")
    cancel_message = fields.Text(
        string="Cancellation Message", default="Your order has been cancelled.")
    auto_confirm = fields.Boolean(
        string="Auto-confirm Order",
        help="Confirm the sale order automatically when the customer replies "
             "DONE/YES. Otherwise it stays a draft quotation for an agent to "
             "review.")
    session_timeout_minutes = fields.Integer(
        string="Session Timeout (min)", default=30)
    item_count = fields.Integer(compute='_compute_item_count')

    @api.depends('section_ids.item_ids')
    def _compute_item_count(self):
        for menu in self:
            menu.item_count = sum(len(s.item_ids) for s in menu.section_ids)

    @api.constrains('section_ids')
    def _check_row_limit(self):
        for menu in self:
            total = sum(len(s.item_ids) for s in menu.section_ids)
            if total > 10:
                raise ValidationError(_(
                    "A WhatsApp list can contain at most 10 rows in total. "
                    "Catalog '%(name)s' has %(count)d.",
                    name=menu.name, count=total))

    def _all_items(self):
        """All items across sections, ordered — used for inbound row matching."""
        self.ensure_one()
        items = self.env['owa.catalog.menu.item']
        for section in self.section_ids.sorted('sequence'):
            items |= section.item_ids.sorted('sequence')
        return items

    def _build_list_sections(self):
        """Build the sections[] payload for the connector's send-list API."""
        self.ensure_one()
        sections = []
        for section in self.section_ids.sorted('sequence'):
            rows = []
            for item in section.item_ids.sorted('sequence'):
                if not item.product_id:
                    continue
                cur = item.product_id.currency_id.name or ''
                desc = (item.custom_description
                        or ("%.2f %s" % (item.product_id.lst_price, cur))).strip()
                rows.append({
                    'id': item.row_id,
                    'title': (item.custom_title or item.product_id.name or '')[:24],
                    'description': desc[:72],
                })
            if rows:
                sections.append({'title': (section.title or '')[:24], 'rows': rows})
        return sections


class OwaCatalogMenuSection(models.Model):
    _name = 'owa.catalog.menu.section'
    _description = 'WhatsApp Catalog Section'
    _order = 'sequence, id'

    menu_id = fields.Many2one(
        'owa.catalog.menu', required=True, ondelete='cascade')
    sequence = fields.Integer(default=10)
    title = fields.Char(required=True, size=24)
    item_ids = fields.One2many(
        'owa.catalog.menu.item', 'section_id', string="Products")


class OwaCatalogMenuItem(models.Model):
    _name = 'owa.catalog.menu.item'
    _description = 'WhatsApp Catalog Item'
    _order = 'sequence, id'

    section_id = fields.Many2one(
        'owa.catalog.menu.section', required=True, ondelete='cascade')
    sequence = fields.Integer(default=10)
    product_id = fields.Many2one(
        'product.product', required=True, domain=[('sale_ok', '=', True)])
    row_id = fields.Char(string="Row ID", readonly=True, copy=False, index=True)
    custom_title = fields.Char(
        string="Row Title",
        help="Overrides the product name on the list row (max 24 chars).")
    custom_description = fields.Char(
        string="Row Description", help="Overrides the price line (max 72 chars).")
    uom_id = fields.Many2one('uom.uom', string="Unit")

    _sql_constraints = [
        ('row_id_uniq', 'unique(row_id)', "Catalog row id must be unique."),
    ]

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get('row_id'):
                vals['row_id'] = uuid.uuid4().hex[:12]
        return super().create(vals_list)
