{
    'name': 'WhatsApp Catalog & Ordering',
    'author': 'Roshan',
    'category': 'Productivity/WhatsApp',
    'summary': 'Interactive product catalog and order-taking over WhatsApp chat '
               '(no AI - rule/menu driven).',
    'license': 'OPL-1',
    'version': '19.0.1.0.0',
    'images': ['static/description/banner.jpg'],
    'description': """
Bridges Open WhatsApp Connector with Sales to let customers browse a curated
product catalog and place an order entirely over WhatsApp - no Meta catalog and
no AI required.

- Build a "Product Catalog" (sections + product rows, max 10 rows per the
  WhatsApp interactive-list limit).
- Customers open it by sending /catalog; the bot replies with a native
  WhatsApp list picker.
- Each pick adds the product to a draft sale.order; the running cart is echoed
  back.
- "DONE" records (optionally auto-confirms) the order; "CANCEL" abandons it.
- Idle sessions auto-expire via a cron.

Auto-installs only when both Open WhatsApp Connector and Sales are installed,
keeping the base connector free of a Sales dependency.
    """,
    'depends': ['open_whatsapp_connector', 'sale'],
    'data': [
        'security/ir.model.access.csv',
        'data/owa_catalog_data.xml',
        'views/owa_catalog_views.xml',
    ],
    'auto_install': True,
    'application': False,
    'installable': True,
    'website': 'https://github.com/roshank8s/',
}
