import { ReceiptScreen } from "@point_of_sale/app/screens/receipt_screen/receipt_screen";
import { patch } from "@web/core/utils/patch";

/**
 * Add a "WhatsApp" send action to the receipt screen. It reuses the core
 * `sendReceipt` tracked-async (which renders the receipt image and calls the
 * given server action), only swapping the action name and destination — so no
 * version-specific hook imports are needed and this file is identical on 18/19.
 */
patch(ReceiptScreen.prototype, {
    actionSendReceiptOnWhatsApp() {
        this.sendReceipt.call({
            action: "action_send_whatsapp_receipt",
            destination: this.state.phone,
            name: "WhatsApp",
        });
    },
});
