from odoo import fields, models


class PosConfig(models.Model):
    _inherit = 'pos.config'

    owa_wa_receipt_enabled = fields.Boolean(
        string="Send Receipt on WhatsApp",
        help="Automatically send the receipt to the customer over WhatsApp when "
             "an order is paid. The manual WhatsApp button on the receipt "
             "screen is always available regardless of this setting.")
    owa_wa_receipt_account_id = fields.Many2one(
        'owa.account', string="WhatsApp Account",
        domain="[('session_state', '=', 'connected')]",
        help="Connected WhatsApp account used to send POS receipts. Falls back "
             "to the first connected account when empty.")
    owa_wa_receipt_template_id = fields.Many2one(
        'owa.quick.reply', string="Receipt Message Template",
        help="Optional message template rendered as the receipt caption.")
