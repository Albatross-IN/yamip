import base64
import logging

from odoo import _, fields, models
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class PosOrder(models.Model):
    _inherit = 'pos.order'

    wa_receipt_sent = fields.Boolean(
        string="WhatsApp Receipt Sent", default=False, copy=False,
        help="Set once a WhatsApp receipt has been sent for this order, so the "
             "auto-send never fires twice.")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _wa_receipt_account(self):
        """Resolve the WhatsApp account: the one set on the PoS, else the first
        connected account."""
        self.ensure_one()
        account = self.config_id.owa_wa_receipt_account_id
        if account and account.session_state == 'connected':
            return account
        return self.env['owa.account'].search(
            [('session_state', '=', 'connected')], limit=1)

    def _wa_receipt_body(self):
        self.ensure_one()
        template = self.config_id.owa_wa_receipt_template_id or self.env.ref(
            'open_whatsapp_connector_pos.quick_reply_pos_receipt',
            raise_if_not_found=False)
        if template:
            return template.render_body(record=self)
        return _("Hi %s, thank you for your purchase! Your receipt for %s is "
                 "attached.") % (self.partner_id.name or '', self.name or '')

    def _wa_queue_receipt(self, account, phone, body, attachment_ids):
        """Create the mail.message + outbound owa.message and kick the cron.

        Builds the mail.message first because owa.message.body is a related,
        read-only field on mail_message_id.body.
        """
        self.ensure_one()
        mail_message = self.env['mail.message'].sudo().create({
            'model': 'pos.order',
            'res_id': self.id,
            'body': body or '',
            'message_type': 'whatsapp_message',
            'attachment_ids': [(6, 0, attachment_ids or [])],
        })
        self.env['owa.message'].sudo().create({
            'mobile_number': phone,
            'message_type': 'outbound',
            'state': 'outgoing',
            'wa_account_id': account.id,
            'mail_message_id': mail_message.id,
        })
        self.wa_receipt_sent = True
        cron = self.env.ref('open_whatsapp_connector.ir_cron_send_owa_queue',
                            raise_if_not_found=False)
        if cron:
            cron.sudo()._trigger()

    # ------------------------------------------------------------------
    # Manual send (WhatsApp button on the receipt screen)
    # ------------------------------------------------------------------
    def action_send_whatsapp_receipt(self, phone, ticket_image, basic_image):
        """RPC for the WhatsApp button on the POS receipt screen.

        Mirrors the signature of the core ``action_send_receipt`` so the same
        front-end ``_sendReceiptToCustomer`` flow drives it.
        """
        self.ensure_one()
        from odoo.addons.open_whatsapp_connector.tools.phone_validation import (
            wa_phone_format)
        formatted = wa_phone_format(self.env, phone or '') or phone
        if not formatted:
            raise UserError(_("Please enter a valid WhatsApp phone number."))
        account = self._wa_receipt_account()
        if not account:
            raise UserError(_(
                "No connected WhatsApp account. Connect one under WhatsApp → "
                "Configuration → Accounts (or set it on this Point of Sale)."))
        # Reuse the core receipt-image + invoice-PDF attachment builder
        # (renamed _add_mail_attachment → _get_mail_attachments in Odoo 19).
        build = getattr(self, '_add_mail_attachment', None) or getattr(
            self, '_get_mail_attachments', None)
        att_cmds = build(self.name, ticket_image, basic_image) if build else []
        att_ids = [c[1] for c in att_cmds if c and c[0] == 4]
        self._wa_queue_receipt(
            account, formatted, self._wa_receipt_body(), att_ids)
        self.mobile = formatted
        return {'successful': True}

    # ------------------------------------------------------------------
    # Auto send on payment
    # ------------------------------------------------------------------
    def write(self, vals):
        res = super().write(vals)
        if vals.get('state') == 'paid' and not self.env.context.get(
                'skip_wa_receipt'):
            for order in self:
                if (order.config_id.owa_wa_receipt_enabled and order.mobile
                        and not order.wa_receipt_sent):
                    try:
                        order.with_context(
                            skip_wa_receipt=True)._wa_receipt_auto_send()
                    except Exception:
                        _logger.exception(
                            "POS WhatsApp auto-receipt failed for order %s",
                            order.id)
        return res

    def _wa_receipt_auto_send(self):
        """Server-side auto send. No browser receipt image is available here,
        so it sends the text body and, when the order is invoiced, the invoice
        PDF."""
        self.ensure_one()
        from odoo.addons.open_whatsapp_connector.tools.phone_validation import (
            wa_phone_format)
        phone = wa_phone_format(self.env, self.mobile or '') or self.mobile
        if not phone:
            return
        account = self._wa_receipt_account()
        if not account:
            return
        att_ids = []
        if self.account_move:
            try:
                report = self.env['ir.actions.report'].sudo()._render_qweb_pdf(
                    "account.account_invoices", self.account_move.ids[0])
                att = self.env['ir.attachment'].sudo().create({
                    'name': '%s.pdf' % (self.account_move.name or self.name),
                    'type': 'binary',
                    'res_model': 'pos.order',
                    'res_id': self.id,
                    'mimetype': 'application/pdf',
                    'datas': base64.b64encode(report[0]),
                })
                att_ids = [att.id]
            except Exception:
                _logger.exception(
                    "POS WhatsApp auto-receipt: invoice PDF render failed for "
                    "order %s", self.id)
        self._wa_queue_receipt(account, phone, self._wa_receipt_body(), att_ids)
