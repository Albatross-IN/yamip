{
    'name': 'WhatsApp POS Receipts',
    'author': 'Roshan',
    'category': 'Productivity/WhatsApp',
    'summary': 'Send POS receipts to customers via WhatsApp at checkout.',
    'license': 'OPL-1',
    'version': '19.0.1.0.0',
    'images': ['static/description/banner.jpg'],
    'description': """
Bridges Open WhatsApp Connector with the Point of Sale module.

- "WhatsApp" send button on the POS receipt screen (mirrors the e-mail button)
  that delivers the receipt image (and the invoice PDF when invoiced) to the
  customer's WhatsApp.
- Optional auto-send: when enabled per Point of Sale, every paid order with a
  customer phone number triggers a WhatsApp receipt automatically.

Auto-installs only when both Open WhatsApp Connector and Point of Sale are
installed, keeping the base connector free of a POS dependency.
    """,
    'depends': ['open_whatsapp_connector', 'point_of_sale'],
    'data': [
        'data/owa_pos_templates.xml',
        'views/pos_config_views.xml',
    ],
    'assets': {
        'point_of_sale._assets_pos': [
            'open_whatsapp_connector_pos/static/src/**/*',
        ],
    },
    'auto_install': True,
    'application': False,
    'installable': True,
    'website': 'https://github.com/roshank8s/',
}
