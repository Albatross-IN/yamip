{
    'name': 'WhatsApp eCommerce Ordering',
    'author': 'Roshan',
    'category': 'Productivity/WhatsApp',
    'summary': 'WhatsApp click-to-order buttons on shop & cart pages + '
               'abandoned-cart recovery reminders.',
    'license': 'OPL-1',
    'version': '19.0.1.0.0',
    'images': ['static/description/banner.jpg'],
    'description': """
Bridges Open WhatsApp Connector with the website_sale (eCommerce) module.

- "Ask on WhatsApp" and "Order on WhatsApp" buttons on every product page.
- "Checkout via WhatsApp" call-to-action on the shopping cart, pre-filled with
  the cart contents and total.
- Optional hourly abandoned-cart recovery: customers who leave items in their
  cart receive a WhatsApp reminder (once each) with a link to resume checkout.

Auto-installs only when both Open WhatsApp Connector and Website Sale are
installed, keeping the base connector free of an eCommerce dependency.
    """,
    'depends': ['open_whatsapp_connector', 'website_sale'],
    'data': [
        'data/owa_quick_reply_data.xml',
        'data/ir_cron_data.xml',
        'views/res_config_settings_views.xml',
        'views/website_sale_product_templates.xml',
        'views/website_sale_cart_templates.xml',
    ],
    'auto_install': True,
    'application': False,
    'installable': True,
    'website': 'https://github.com/roshank8s/',
}
