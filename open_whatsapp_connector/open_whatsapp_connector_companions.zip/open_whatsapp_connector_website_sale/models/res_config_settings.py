from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    owws_shop_wa_phone = fields.Char(
        string="Shop WhatsApp Number",
        config_parameter='owws.shop_wa_phone',
        help="The shop's WhatsApp number that receives 'Order on WhatsApp' and "
             "'Checkout via WhatsApp' messages from the eCommerce site. "
             "Falls back to the Website WhatsApp Widget number when empty.")
    owws_abandoned_cart_wa = fields.Boolean(
        string="Abandoned Cart Recovery via WhatsApp",
        config_parameter='owws.abandoned_cart_wa',
        help="When enabled, an hourly cron messages customers who left items in "
             "their cart, once per cart.")
    owws_wa_account_id = fields.Many2one(
        'owa.account', string="eCommerce WhatsApp Account",
        config_parameter='owws.wa_account_id',
        help="Connected WhatsApp account used to send abandoned-cart reminders.")

    @api.model
    def get_values(self):
        res = super().get_values()
        param = self.env['ir.config_parameter'].sudo()
        # Pre-fill the shop number from the website-widget phone when the admin
        # has not set a dedicated eCommerce number yet (avoid double entry).
        if not param.get_param('owws.shop_wa_phone'):
            res['owws_shop_wa_phone'] = param.get_param(
                'open_whatsapp_connector.website_widget_phone') or False
        return res
