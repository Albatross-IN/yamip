import logging

from odoo import api, fields, models

_logger = logging.getLogger(__name__)


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    wa_cart_recovery_sent = fields.Boolean(
        string="WhatsApp Recovery Sent", default=False, copy=False,
        help="Set once an abandoned-cart WhatsApp reminder has been sent for "
             "this cart, so the recovery cron never double-messages it.")

    def _wa_build_cart_summary(self):
        """Plain-text bullet list of the cart lines for the prefilled message.

        Single newlines survive ``html2plaintext`` on the send path, so one
        bullet per line renders correctly on WhatsApp.
        """
        self.ensure_one()
        lines = []
        for line in self.website_order_line:
            if not line.product_id:
                continue
            sym = line.currency_id.symbol or self.currency_id.symbol or ''
            lines.append("• %s x%d — %s%.2f" % (
                line.product_id.name, int(line.product_uom_qty),
                sym, line.price_total))
        return "\n".join(lines)

    def _wa_build_cart_url(self):
        """Tokenised cart URL the customer can open to resume checkout."""
        self.ensure_one()
        self.sudo()._portal_ensure_token()
        return "%s/shop/cart?access_token=%s" % (
            self.get_base_url(), self.sudo().access_token)

    @api.model
    def _cron_wa_abandoned_cart(self):
        """Hourly: WhatsApp-remind customers who left a cart behind, once each.

        Mirrors website_sale's own ``_send_abandoned_cart_email`` selection
        (``is_abandoned_cart``) but gates on a phone number and a dedicated
        ``wa_cart_recovery_sent`` flag so e-mail and WhatsApp recovery stay
        independent.
        """
        param = self.env['ir.config_parameter'].sudo()
        if param.get_param('owws.abandoned_cart_wa') != 'True':
            return
        account_id = int(param.get_param('owws.wa_account_id') or 0)
        if not account_id:
            return
        account = self.env['owa.account'].browse(account_id)
        if not account.exists() or account.session_state != 'connected':
            return

        from odoo.addons.open_whatsapp_connector.tools.phone_validation import (
            wa_phone_format)
        template = self.env.ref(
            'open_whatsapp_connector_website_sale.owws_cart_recovery_template',
            raise_if_not_found=False)

        abandoned = self.sudo().search([
            ('is_abandoned_cart', '=', True),
            ('wa_cart_recovery_sent', '=', False),
            ('partner_id.phone', '!=', False),
        ])
        sent = 0
        for order in abandoned:
            phone = wa_phone_format(self.env, order.partner_id.phone or '')
            if not phone:
                # Bad/unparseable number — mark sent so we stop retrying it.
                order.wa_cart_recovery_sent = True
                continue
            free = {
                'partner_name': order.partner_id.name or '',
                'cart_lines': order._wa_build_cart_summary(),
                'cart_total': "%s%.2f" % (
                    order.currency_id.symbol or '', order.amount_total),
                'cart_url': order._wa_build_cart_url(),
            }
            body = template.render_body(record=order, free_text_values=free) \
                if template else ''
            if not body:
                continue
            mail_message = self.env['mail.message'].sudo().create({
                'model': 'sale.order',
                'res_id': order.id,
                'body': body,
                'message_type': 'whatsapp_message',
            })
            self.env['owa.message'].sudo().create({
                'mobile_number': phone,
                'message_type': 'outbound',
                'state': 'outgoing',
                'wa_account_id': account.id,
                'mail_message_id': mail_message.id,
            })
            order.wa_cart_recovery_sent = True
            sent += 1

        if sent:
            cron = self.env.ref(
                'open_whatsapp_connector.ir_cron_send_owa_queue',
                raise_if_not_found=False)
            if cron:
                cron.sudo()._trigger()
            _logger.info(
                "owa ecom: queued %s abandoned-cart WhatsApp reminders", sent)
